#functions
def shift_right(x,shift):
    x =str(x)
    dec1 = int(x,2)
    decShift = dec1 >> shift
    binOut = bin(decShift)
    binOut= binOut.replace("0b","")
    return binOut.zfill(len(x))

def rotate_right(x,d):
    Rfirst = x[0 : len(x)-d]
    Rsecond = x[len(x)-d : ]
    return (Rsecond+Rfirst)

def choose(x, y, z):
        decx = int(x,2)
        decy = int(y,2)
        decz = int(z,2)
        value = decz ^ (decx & (decy ^ decz))
        binOut = bin(value)
        return binOut.replace("0b","").zfill(len(x))
def majority(x, y, z):
    decx = int(x,2)
    decy = int(y,2)
    decz = int(z,2)
    value = ((decx | decy) & decz) | (decx & decy)
    binOut = bin(value)
    return binOut.replace("0b","").zfill(len(x))

def sigma0(x):
    # ROTR 2(x) ⊕ ROTR 13(x) ⊕ ROTR 22(x)
    return rotate_right(x, 2) ^ rotate_right(x, 13) ^ rotate_right(x, 22)


def sigma1(x):
    # ROTR 6(x) ⊕ ROTR 11(x) ⊕ ROTR 25(x)
    return rotate_right(x, 6) ^ rotate_right(x, 11) ^ rotate_right(x, 25)


def gamma0(x):
    # ROTR 7(x) ⊕ ROTR 18(x) ⊕ SHR 3(x)
    return rotate_right(x, 7) ^ rotate_right(x, 18) ^ shift_right(x, 3)


def gamma1(x):
    # ROTR 17(x) ⊕ ROTR 19(x) ⊕ SHR 10(x)
    return rotate_right(x, 17) ^ rotate_right(x, 19) ^ shift_right(x, 10)

#starting of sha 256

##padding
message = input("enter the message")
phrase_size=len(message)*8
phrase_size_in_bin=bin(phrase_size)
phrase_size_in_bin=phrase_size_in_bin.replace("0b","")
binmessage= ''.join(format(ord(i), '08b') for i in message) # converts messgage into binary
binmessage= binmessage.ljust(len(binmessage)+1, '1') #adds 1 at the end of the string before padding
binmessage= binmessage.ljust(448, '0')
if len(phrase_size_in_bin)!=64:
    phrase_size= phrase_size_in_bin.rjust(64, '0')

binmessage= binmessage+phrase_size_in_bin #addition of phrase size in binary at the end of padded messag
print(len(binmessage))

## message schedule

chunks = []

i = 0
n=32
while i < len(binmessage):
    if i+n < len(binmessage):
        chunks.append(str[i:i+n])
    else:
        chunks.append(str[i:len(binmessage)])
    i += n
print(chunks)